#pragma once
#include <array>
#include <iostream>
#include <cassert>
#include <array>
#include <cmath>
#include "VectorOperations.h"

template <typename T, size_t N>
class FunzioneVettorialeBase
{
public:
    virtual ~FunzioneVettorialeBase() {};
    virtual array<T, N> eval(double x, const array<T, N> &a) const = 0;
};

// oscillatore armonico a una dimensione ossia a 2 dimensioni nello spazio delle fasi
//  lo spazio delle fasi è composto da x(t) e v(t)

// N/2 quindi mi indica i gradi di libertà

// prima componente dell'array x
// seconda componente dell'array v
class OscillatoreArmonico : public FunzioneVettorialeBase<double, 2>
{
public:
    OscillatoreArmonico(double omega) { m_omega = omega; }
    array<double, 2> eval(double t, const array<double, 2> &a) const override
    {
        array<double, 2> risultato{};
        risultato[0] = a[1];                      // x
        risultato[1] = (-pow(m_omega, 2)) * a[0]; // v
        return risultato;
    }
    double getOmega() const { return m_omega; }

private:
    double m_omega;
};

// pendolo
class Pendolo : public FunzioneVettorialeBase<double, 2>
{
public:
    Pendolo(double lunghezza, double gravitazione)
    {
        m_lunghezza = lunghezza;
        m_gravitazione = gravitazione;
    }
    array<double, 2> eval(double t, const array<double, 2> &a) const override
    {
        array<double, 2> risultato{};
        risultato[0] = a[1];                                            // x
        risultato[1] = (-(m_gravitazione / m_lunghezza) * (sin(a[0]))); // v
        return risultato;
    }

private:
    double m_lunghezza;
    double m_gravitazione;
};

// tema esame
class TEMA2 : public FunzioneVettorialeBase<double, 2>
{
public:
    TEMA2(double omega, double alfa)
    {
        m_alfa = alfa;
        m_omega = omega;
    }

    double getAlfa() { return m_alfa; }
    double getOMEGA() { return m_omega; }

    // x e y 1 e 2
    // v_x e v_y 3 e 4
    array<double, 2> eval(double t, const array<double, 2> &a) const override
    {
        array<double, 2> coordinate{};
        coordinate[0] = a[1];                                      // x = v_x
        coordinate[1] = -m_omega * m_omega * a[0] - m_alfa * a[1]; // v_x = v_y
        return coordinate;
    }

private:
    double m_omega, m_alfa;
};

// tema esame
class TEMA1 : public FunzioneVettorialeBase<double, 4>
{
public:
    TEMA1(double alfa)
    {
        m_alfa = alfa;
    }

    double getR() { return m_r; }
    void setR(double r) { m_r = r; }

    // x e y 1 e 2
    // v_x e v_y 3 e 4
    array<double, 4> eval(double t, const array<double, 4> &a) const override
    {
        array<double, 4> coordinate{};
        double r = (sqrt(a[0] * a[0] + a[1] * a[1]));
        double B_r_quasi = (1.0 / (pow(r, m_alfa))) + 1;
        coordinate[0] = a[2];              // x = v_x
        coordinate[1] = a[3];              // y = v_y
        coordinate[2] = -B_r_quasi * a[3]; // v_x
        coordinate[3] = B_r_quasi * a[2];
        return coordinate;
    }

protected:
    double m_alfa;
    double m_r;
};

// oscillatore forzato dopo averlo smorzato
class OscillatoreForzato : public FunzioneVettorialeBase<double, 2>
{
public:
    OscillatoreForzato(double omega, double alfa, double omegaf)
    {
        m_omega = omega;
        m_alfa = alfa;
        m_omegaf = omegaf;
    }
    array<double, 2> eval(double t, const array<double, 2> &a) const override
    {
        array<double, 2> risultato{};
        risultato[0] = a[1];                                                                // x
        risultato[1] = (-pow(m_omega, 2)) * a[0] - m_alfa * a[1] + 1.0 * sin(m_omegaf * t); // v
        return risultato;
    }
    double getOmega() const { return m_omega; }
    double getOmegaf() const { return m_omegaf; }
    double getalfa() const { return m_alfa; }

private:
    double m_omega;
    double m_omegaf;
    double m_alfa;
};

class SpintaIniziale : public FunzioneVettorialeBase<double, 4>
{
public:
    SpintaIniziale(double theta_0, double Spinta, double Massa)
    {
        m_theta0 = theta_0;
        m_spinta = Spinta;
        m_massa = Massa;
    }
    array<double, 4> eval(double t, const array<double, 4> &a) const override
    {
        array<double, 4> risultato{};
        risultato[0] = a[2]; // x
        risultato[1] = a[3];
        if (t <= 1.0)
        {
            risultato[2] = m_spinta / m_massa * cos(m_theta0);
            risultato[3] = m_spinta / m_massa * sin(m_theta0) - g;
        }
        else
        {
            risultato[2] = 0;
            risultato[3] = -g;
        }
        return risultato;
    }

private:
    double m_theta0;
    double m_spinta;
    double m_massa;
    const double g = 9.80665;
};

class Forza_Lorentz : public FunzioneVettorialeBase<double, 4>
{
public:
    Forza_Lorentz(double massa, double carica, double campo_magnetico)
    {
        m_massa = massa;
        m_carica = carica;
        m_campo = campo_magnetico;
    }
    array<double, 4> eval(double t, const array<double, 4> &a) const override
    {
        array<double, 4> risultato{};
        risultato[0] = a[2];                                   // x
        risultato[1] = a[3];                                   // y
        risultato[2] = -(m_carica / m_massa) * m_campo * a[3]; // v_x
        risultato[3] = (m_carica / m_massa) * m_campo * a[2];  // v_x
        return risultato;
    }

    double getMassa() const { return m_massa; }

private:
    double m_carica;
    double m_massa;
    double m_campo;
};

class Forza_LorentzNonOmogenea : public FunzioneVettorialeBase<double, 4>
{
public:
    Forza_LorentzNonOmogenea(double massa, double carica, double campo_magnetico)
    {
        m_massa = massa;
        m_carica = carica;
        m_campo = campo_magnetico;
    }

    void setMassa(double massa) { m_massa = massa; }

    double raggio(const array<double, 4> iniziali) const
    {
        double x = iniziali[0];
        double y = iniziali[1];
        double r = sqrt(x * x + y * y);
        return r;
    }

    array<double, 4> eval(double t, const array<double, 4> &a) const override
    {
        array<double, 4> risultato{};
        risultato[0] = a[2];                                                        // x
        risultato[1] = a[3];                                                        // y
        risultato[2] = -(m_carica / m_massa) * m_campo * a[3] * pow(e, -raggio(a)); // v_x
        risultato[3] = (m_carica / m_massa) * m_campo * a[2] * pow(e, -raggio(a));  // v_x
        return risultato;
    }

    double getMassa() const { return m_massa; }

private:
    const double e = 2.71828182845904523536;
    double m_carica;
    double m_massa;
    double m_campo;
};

template <typename T, size_t N>
class EquazioneDifferenzialeBase
{
    // passo_h --> passo h
public:
    virtual std::array<double, N>
    Passo(double t, const std::array<double, N> &x, double h,
          const FunzioneVettorialeBase<double, N> &f) const = 0;
};

template <typename T, size_t N>
class Eulero : public EquazioneDifferenzialeBase<double, N>
{
public:
    virtual std::array<double, N>
    Passo(double t, const std::array<double, N> &x, double h,
          const FunzioneVettorialeBase<double, N> &f) const override
    {
        array<double, 2> risultato{};
        risultato = x + (f.eval(t, x) * h);
        return risultato;
    }
};

template <typename T, size_t N>
class RungeK : public EquazioneDifferenzialeBase<double, N>
{
    // f eval mi restituisce xpunto(t, x)
public:
    virtual std::array<double, N>
    Passo(double t, const std::array<double, N> &x, double h,
          const FunzioneVettorialeBase<double, N> &f) const override
    {
        array<double, N> risultato{};
        array<double, N> k1{}, k2{}, k3{}, k4{};
        k1 = f.eval(t, x);
        k2 = (f.eval(t + h / 2, x + (k1 * (h / 2.0))));
        k3 = (f.eval(t + h / 2, x + (k2 * (h / 2.0))));
        k4 = (f.eval(t + h, x + k3 * h));

        risultato = x + (k1 + k2 * 2.0 + k3 * 2.0 + k4) * (h / 6.0);
        return risultato;
    }
};
